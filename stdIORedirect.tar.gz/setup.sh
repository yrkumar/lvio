echo "Copying files to templates directory..."
tar xvf std\ IO\ Project\ Template.tar.gz -C /usr/local/natinst/LabVIEW-2014-64/ProjectTemplates/Source

echo "Copying xml metadata..."
cp NILV_stdIO_Template_Metadata.xml  /usr/local/natinst/LabVIEW-2014-64/ProjectTemplates/Metadata

